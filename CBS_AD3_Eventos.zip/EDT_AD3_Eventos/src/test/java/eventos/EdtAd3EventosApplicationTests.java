package eventos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdtAd3EventosApplicationTests {

	@Test
	void contextLoads() {
	}

}
