package eventos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdtAd3EventosApplication {

	public static void main(String[] args) {
		SpringApplication.run(EdtAd3EventosApplication.class, args);
	}

}
