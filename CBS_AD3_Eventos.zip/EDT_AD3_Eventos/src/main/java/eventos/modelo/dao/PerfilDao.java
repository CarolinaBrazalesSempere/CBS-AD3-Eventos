package eventos.modelo.dao;

import eventos.modelo.entitis.Perfil;

public interface PerfilDao {
	
	Perfil findById(int idPerfil); 
}
